
public class Triangulo extends Poligono{

	@Override
	public double area (){
		return 0;
	}
}
