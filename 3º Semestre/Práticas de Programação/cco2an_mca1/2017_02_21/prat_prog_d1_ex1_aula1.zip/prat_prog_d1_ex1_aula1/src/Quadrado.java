
public class Quadrado extends Poligono implements Diagonal{

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public double diagonal() {
		// TODO Auto-generated method stub
		return 0;
	}

}
