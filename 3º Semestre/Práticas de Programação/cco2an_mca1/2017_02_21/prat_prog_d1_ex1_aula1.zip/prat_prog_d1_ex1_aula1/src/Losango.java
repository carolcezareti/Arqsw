
public class Losango extends Poligono {

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}

}
