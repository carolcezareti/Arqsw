
public interface Diagonal {
	public abstract double diagonal ();
}
