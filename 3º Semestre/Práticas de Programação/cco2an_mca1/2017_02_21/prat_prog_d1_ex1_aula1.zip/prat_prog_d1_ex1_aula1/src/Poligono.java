
public abstract class Poligono extends Figura {

	private double base;
	private double altura;
	
	

}
