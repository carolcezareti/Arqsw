
public class Circulo extends Figura {

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}

}
