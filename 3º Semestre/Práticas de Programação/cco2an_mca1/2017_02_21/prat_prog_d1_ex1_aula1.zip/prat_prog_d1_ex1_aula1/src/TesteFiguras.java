import java.util.ArrayList;

public class TesteFiguras {

	public static void main(String[] args) {
		ArrayList <Figura> figuras = new ArrayList <> ();
		figuras.add(new Circulo());
		figuras.add(new Triangulo());
		figuras.add(new Losango());
		figuras.add(new Retangulo());
		figuras.add(new Quadrado());
		
		for (Figura f : figuras){
			f.area();
			
			if (f instanceof Diagonal){
				((Diagonal)f).diagonal();
			}
		}

	}

}
